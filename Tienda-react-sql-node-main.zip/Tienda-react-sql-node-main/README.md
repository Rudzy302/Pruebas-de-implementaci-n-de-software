#🛒📉 tienda en linea con SQL y PHP
```
codigo libre de una tienda online, las tecnologias usadas son react(axios), node(expres,sql) y sql, 
```
Este es un proyecto de tienda a escala media que aun se encuentra en desarrollo el, la version final sera marcada por medio de este mismo readme con una imagen o texto que lo indique, por lo pronto el sistema ya puede ser usado conjunto a la base de datos incluido en este mismo repositorio, para desarrollo de sistemas a la medida puedes buscar mis metodos de contacto en mi perfil ✋, la contraseña y usuario mostrado a continuacion aun no estan habilitadas


usuario Admin:<br>
  ``` 
  *user     :  Admin
  *password :  admin
  ``` 
  ``
  sistema incompleto, aun se trabaja en el 
  ``

![Tienda en linea SQl](https://github.com/Ilesandres/img_Proyects/blob/main/tieda-homepage.png)
![productos](https://github.com/Ilesandres/img_Proyects/blob/main/tieda-products.png)


<a href="https://opposite-snapper-e2c.notion.site/Platvent-Store-c40ac8fd6c4e44069e7a1f825ba7c1a0" target="blank"><img align="center" src="https://github.com/Ilesandres/img_Proyects/blob/main/platvent_tareas_notion.png" alt="notion" height="100%" width="100%" /></a>


## 📋 Tabla de contenidos


- [✨Características](#características)
- [📝🗒estructura del proyecto](#estructura-del-proyecto)
  - [Estructura del Proyecto](#estructura-del-proyecto-1)
  - [📝 Licencia](#-licencia)

</br>
##demas

## Tecnologias usadas:
- [Expo](https://expo.io/)
- [Node.js](https://nodejs.org/en/)
- [React](https://pt-br.reactjs.org/)
- [React Native](https://reactnative.dev/)
- [TypeScript](https://www.typescriptlang.org/)
- [MySQL](https://www.mysql.com/products/workbench/)
- [moment-timezone]()
  //back-end
  ~npm install moment-timezone



## 📦 Instalación

1. Clona el repositorio a tu máquina local:
   ```bash
   git clone https://github.com/Ilesandres/Tienda-react-sql-nodet
   $cd tienda-v2

   cliente
      $cd client
      $npm start

    server
      $cd server
      $node index.js


2. Puedes usar una base de datos local, e importar la base de datos que te dejo adjunta
3. para uso movil se recomienda con el uso o orientacion horizontal
      ![orientacion movil](https://github.com/Ilesandres/img_Proyects/blob/main/orientacionmovilHorizontal.jpg)

# ✨Características
* <b>Autenticacion de Usuarios :</b> Registro de inicio de sesion
* <b>Gestion de productos :</b> añadir, editar y eliminar productos
* <b>Funcionalidad de Ventas : </b> realiza ventas, modificalas y eliminalas e imprimelas, 
* <b>REsponsive Design : </b> adaptado para dispositvos moviles y de escritorio(aun trabajando en esto)


#  📝🗒estructura del proyecto

  Tienda  <br>
|--Descripción de cada carpeta:</br>
|--client: Contiene el código fuente de la aplicación cliente (front-end).</br>
|--layout: Define la estructura general de las páginas.</br>
|--modules: Contiene componentes y lógica modularizada.</br>
|--views: Contiene las vistas individuales de la aplicación.</br>
|--server: Contiene el código del servidor (back-end).</br>
|--docs: Documentación adicional (si existe).</br>
|--node_modules: Contiene las dependencias del proyecto.</br>

## Estructura del Proyecto

* **client:**
  * **layout:**
  * **modules:**
  * **views:**
* **server:**
* **docs:**

## 📝 Licencia
Este proyecto está bajo la Licencia MIT. Mira el archivo LICENSE para más detalles(aun no se encuentra añadido).