import React from 'react';
import Homepage from './homepage';

const Login = () => {
    return (
        <div>
            <Homepage/>
        </div>
    );
};

export default Login;
