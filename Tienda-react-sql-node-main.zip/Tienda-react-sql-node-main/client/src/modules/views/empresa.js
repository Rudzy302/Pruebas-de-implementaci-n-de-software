import React from 'react';

const Empresa = () => {
    return (
        <div>
            
        </div>
    );
};

export default Empresa;
