import React from 'react';

const NavbarHomepage = () => {
    return (
        <div>
           var navegacion de home
        </div>
    );
};

export default NavbarHomepage;
